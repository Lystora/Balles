import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Fenetre extends JFrame implements ActionListener{

	private Panneau pan = new Panneau();
	JButton start_stop;
	JButton bt_ajoute;
	JButton bt_retire;
	JLabel nb_colli= new JLabel("Nombre de collision : "+Integer.toString(pan.nb_collision));
	Thread t1 = new Thread(pan);
	
	public Fenetre() {
		JFrame fen = new JFrame();
		Container conteneur = fen.getContentPane();
		conteneur.setLayout(new BorderLayout());

		//[gestion de la fermeture de la fen�tre
		fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		fen.setTitle("Animation");
		fen.setSize(300, 300);
		fen.setLocationRelativeTo(null);
		fen.setVisible(true);

		//[Zone bas
		JPanel zone1 = new JPanel();
		zone1.setLayout(new FlowLayout());
		conteneur.add(zone1, BorderLayout.SOUTH);

		//[Zone haut
		JPanel zone2 = new JPanel();
		zone2.setLayout(new FlowLayout());
		conteneur.add(zone2, BorderLayout.NORTH);
		
		nb_colli.setText("Nombre de collision : "+Integer.toString(pan.nb_collision));
		zone2.add(nb_colli);

		//[Boutons
		start_stop = new JButton("stop");
		bt_ajoute = new JButton("+");
		bt_retire = new JButton("-");
		zone1.add(start_stop);
		zone1.add(bt_ajoute);
		zone1.add(bt_retire);
		
		//[Ecoute des �v�nements
		start_stop.addActionListener(this);
		bt_ajoute.addActionListener(this);
		bt_retire.addActionListener(this);

		//[Ajout du thread
		
		t1.start();
		conteneur.add(pan);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		Color[] Tab = {Color.black, Color.blue, Color.cyan, Color.red, Color.green, Color.magenta, Color.orange, Color.yellow };

		if(source instanceof JButton) {
			JButton bt_source = (JButton) source;
			String bt_titre = bt_source.getText();

			switch(bt_titre) {
			case "+":
				if(pan.cercle.size() < 10) {
					Cercle c1 = new Cercle((int)(Math.random()*(300-0)+1),(int)(Math.random()*(300-0)+1),50);
					c1.setColor(Tab[(int)(Math.random()*8)]);
					pan.cercle.add(c1);
				}
				break;
				
			case "-":
				if(pan.cercle.size() > 0) {
					pan.cercle.remove(pan.cercle.get(pan.cercle.size()-1));
					pan.repaint();
				}
				break;
			case "stop":
				start_stop.setText("start");
				t1.interrupt();
				break;
			case "start":
				start_stop.setText("stop");
				t1.start();
				break;
			}
			
		}

	}

	public static void main(String[] args) {
		Fenetre fen = new Fenetre();
	}
}